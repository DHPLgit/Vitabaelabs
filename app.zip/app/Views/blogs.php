<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <section class="blog-banner">
    <!-- <img src="https://www.vitabae.com/blogs/images/banner/blog-banner.png" class="img-fluid" alt="..."> -->
    <center>
        <h1>Discover Your path to Wellness</h1>
    </center>
</section>

<section class="blog" id="blog-section">
    <div class="container">
        <!-- Count of selected tags -->
        <div class="row mb-3">
            <!-- Sidebar -->
            <div class="col-md-3">
                <form id="filterForm" method="get" action="">
                    <div class="accordion" id="tagsAccordion">
                    <?php foreach ($groupedTags as $header => $tags): ?>
                        <?php if (!empty($tags)): ?>
                            <?php $headerTitle = !empty($tags[0]['title']) ? $tags[0]['title'] : $header;
                            //$sanitizedHeaderTitle = htmlspecialchars(str_replace(' ', '-', $headerTitle));
                            $displayHeaderTitle = htmlspecialchars($headerTitle);

                            $headerTitle = htmlspecialchars(str_replace(' ', '-', $headerTitle));

                            ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading-<?=($headerTitle) ?>">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapse-<?= ($headerTitle) ?>" aria-expanded="true"
                                            aria-controls="collapse-<?= ($headerTitle) ?>">
                                        <?= ($displayHeaderTitle) ?>
                                    </button>
                                </h2>
                                <div id="collapse-<?= ($headerTitle) ?>"
                                    class="accordion-collapse collapse show" aria-labelledby="heading-<?= ($headerTitle) ?>"
                                    data-bs-parent="#tagsAccordion">
                                    <div class="accordion-body">
                                        <?php foreach ($tags as $tag): ?>
                                            <?php if (!empty($tag['title']) && $tag['title'] !== $headerTitle): ?>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="tags[]"
                                                        value="<?= htmlspecialchars($tag['id']) ?>"
                                                        id="tag-<?= htmlspecialchars($tag['id']) ?>"
                                                        <?= in_array($tag['id'], $selectedTags ?? []) ? 'checked' : '' ?>
                                                        onchange="this.form.submit()">
                                                    <label class="form-check-label"
                                                        for="tag-<?= htmlspecialchars($tag['id']) ?>">
                                                        <?= htmlspecialchars($tag['title'])?>
                                                    </label>
                                                    <span class="checkmark"></span>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    </div>
                </form>
            </div>

            <!-- Blog List -->
            <div class="col-md-9">
                <div class="row">
                    <!-- Blog List Section -->
                    <div class="col-12">
                    <div class="count-head-blog">
                        <?php if (empty($selectedTags)): ?>
                            <span><?= $totalBlogs ?></span> Results
                        <?php else: ?>
                            <span><?= count($blogs) ?></span> Results for 
                                <span>
                                    <?php
                                        $selectedTagTitles = [];
                                        foreach ($groupedTags as $header => $tags) {
                                            foreach ($tags as $tag) {
                                                if (in_array($tag['id'], $selectedTags)) {
                                                    $selectedTagTitles[] = '"' . htmlspecialchars($tag['title']) . '"';
                                                }
                                            }
                                        }
                                        echo implode(', ', $selectedTagTitles);
                                    ?>
                                </span>
                        <?php endif; ?>
                    </div>

                        <div class="row">
                            <?php if (!empty($blogs)): ?>
                                <?php foreach ($blogs as $blog): ?>
                                    <?php if (isset($blog['id'])): ?>
                                        <div class="col-sm-6">
                                            <div class="blog-list">
                                                <div class="blog-list-img">
                                                    <a href="<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['additional_value']) ?>">
                                                        <img src="<?= htmlspecialchars('https://vitabaelabs.in/adminblog/' . $blog['images']['image_intro']) ?>"
                                                        alt="<?= htmlspecialchars($blog['images']['image_intro_alt']) ?>" class="img-fluid">
                                                    </a>
                                                </div>
                                                <div class="blog-list-content">
                                                    <div class="title-head rainbow">
                                                        <!--<?php if (isset($blog['tagGr'])): ?>-->
                                                        <!--    <span class="badge bg-primary"><?= htmlspecialchars($blog['tagGr']) ?></span><br>-->
                                                        <!--<?php endif; ?>-->
                                                        <a href="<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['additional_value']) ?>">
                                                            <?= htmlspecialchars($blog['title']); ?>
                                                        </a><br />
                                                    </div>
                                                    <div class="blog-footer">
                                                        <p><?= htmlspecialchars($blog['read']) ?> mins read</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <!--<p>No blogs found.</p>-->
                            <?php endif; ?>
                        </div>

                        <!-- Pagination Section -->
                        <?php if ($totalPages > 1): ?>
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                        <li class="page-item <?= ($i == $currentPage) ? 'active' : '' ?>">
                                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                        </li>
                                    <?php endfor; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Today's Pick Section -->
        <div class="col-12 mt-4">
            <h2 class="todys-pick-head">Today's Picks</h2>
            <div class="row">
                <?php foreach ($todaysPick as $pick): ?>
                    <div class="col-sm-6 col-lg-4">
                        <div class="blog-list">
                            <div class="blog-list-img">
                                <a href="<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($pick['additional_value']) ?>">
                                    <img src="<?= htmlspecialchars('https://vitabaelabs.in/adminblog/' . $pick['images']['image_fulltext']) ?>"
                                    alt="<?= htmlspecialchars($pick['images']['image_intro_alt']) ?>" class="img-fluid">
                                </a>
                            </div>
                            <div class="blog-list-content">
                                <div class="title-head rainbow">
                                    <a href="<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($pick['additional_value']) ?>">
                                        <?= htmlspecialchars($pick['title']); ?>
                                    </a>
                                </div>
                                <div class="blog-footer">
                                    <p><?= htmlspecialchars($pick['read']) ?> mins read</p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXlBv3f4xZLYBOs2TzNlK8dHNDO9Yk7FnjDMG/aDNf2F5C6eXc/ujB8MX6jQ" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGhliT6HfUbYgTXo2Qe8dHNDO9Yk7FnjDMG/aDNf2F5C6eXc/ujB8MX6jQ" crossorigin="anonymous"></script>
<script>
    document.getElementById("pageTitle").innerText = "Blogs";

    window.onload = function () {
        // Scroll to the blog section after the page loads
        document.getElementById('blog-section').scrollIntoView({
            behavior: 'smooth'
        });
    };

    document.getElementById('filterForm').onsubmit = function () {
        // Scroll to the blog section after the form is submitted
        setTimeout(function () {
            document.getElementById('blog-section').scrollIntoView({
                behavior: 'smooth'
            });
        }, 100); // Small delay to ensure form submission happens first
    };
</script>
<?= $this->endSection() ?>
