<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>

<section class="farmer-banner">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 col-md-8 col-sm-12 dis-center" >
                <div class="join-banner-content d-none d-lg-block">
                    <h2>Welcome To The <br /><span>Vitabae Farmers</span><br /> Community</h2>
                    <p>At Vitabae, we highly value our partnership with farmers, as it's the foundation of our
                        commitment to quality and sustainability. Learn how our farming practices ensure top-quality
                        ingredients in every Vitabae supplement.</p>
                    <app-contactbtn></app-contactbtn>
                </div>
               
            </div>
            <div class="col-lg-6 col-md-4 col-sm-12"  style="padding:0px">
                <img src="<?php echo base_url(); ?>image/banner/farmer-banner-new.png" class="img-fluid  banner-home d-none d-lg-block"/>
                
                
            </div>
            <img src="<?php echo base_url(); ?>image/banner/farmer-banner-sm-new.png" class="img-fluid d-lg-none" />
            <div class="join-banner-content d-lg-none">
                    <h2>Welcome To The <span>Vitabae Farmers</span> Community</h2>
                    <p>At Vitabae, we highly value our partnership with farmers, as it's the foundation of our
                        commitment to quality and sustainability. Learn how our farming practices ensure top-quality
                        ingredients in every Vitabae supplement.</p>
                    <!-- <button class="btn" (click)="goToVotes()">Sign up</button> -->
                </div>
        </div>
    </div>
</section>
<section class="farmer-why">
    <div class="container-fluid">
        <h2>Why Partner With <br class="d-lg-none"/><span> Vitabae Labs </span></h2>
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-1">
                    <h4>Market Access</h4>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-2">
                    <h4>Innovation</h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-3">
                    <h4>Expertise</h4>
                </div>
            </div>
            <div class="col-md-6 col-sm-12">
                <div class="farmer-why-content-4">
                    <h4>Long-term
                        Partnership</h4>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="case-studies">
    <div class="container">
        <div class="case-studies-content">
            <h2>Read Our Case Studies</h2>
            <p>Discover the success stories behind our collaborations with industry partners. Explore how Vitabae's commitment to innovation and partnership has led to outstanding results. Dive into our case studies to learn more about our journey towards excellence.</p>
            <button class="btn">Read more</button>
        </div>
    </div>
</section>
<section class="que">
    <div class="container">
        <div class="que-content">
            <h2>Questions?</h2>
            <p>We have answers! Check out our handy FAQ for
                insights and info on all things vitabae</p>
            <div class="d-flex justify-content-center">
                <a  href="<?= base_url('/askanything') ?>">Open the FAQ’s</a>
                <img src="<?php echo base_url(); ?>image/icons/farmer-arrow.png" class="img-fluid"/>
            </div>
        </div>
    </div>
</section>

<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>