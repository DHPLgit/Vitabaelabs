<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<section class="faq-banner">
    <div class="container">
        <div class="faq-banner-content">
            <h5>FAQ's</h5>
            <h1>Ask Us <span>Anything</span></h1>
            <p>Have any questions? We're here to assist you.</p>
            <form>
                <div class="form-field">
                    <input type="search" class="search" placeholder="Search" />
                </div>
            </form>
        </div>
    </div>
</section>
<section class="faq">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="faq-content">
                    <img src="<?php echo base_url(); ?>image/icons/icon-5.png" class="img-fluid" />
                    <h3>How do I change my account email?</h3>
                    <p>You can log in to your account and change it from your Profile > Edit Profile. Then go to the
                        general tab to change your email.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="faq-content">
                    <img src="<?php echo base_url(); ?>image/icons/icon-4.png" class="img-fluid" />
                    <h3>What should I do if my payment fails?</h3>
                    <p>If your payment fails, you can use the (COD) payment option, if available on that order. If your payment is debited from your account after a payment failure, it will be credited back within 7-10 days.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="faq-content">
                    <img src="<?php echo base_url(); ?>image/icons/icon-3.png" class="img-fluid" />
                    <h3>What is your cancellation policy?</h3>
                    <p>You can now cancel an order when it is in packed/shipped status. Any amount paid will be credited into the same payment mode using which the payment was made</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="faq-content">
                    <img src="<?php echo base_url(); ?>image/icons/icon-6.png" class="img-fluid" />
                    <h3>How do I check order delivery status ?</h3>
                    <p>Please tap on “My Orders” section under main menu of App/Website/M-site to check your order status.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="faq-content">
                    <img src="<?php echo base_url(); ?>image/icons/icon-2.png" class="img-fluid" />
                    <h3>What is Instant Refunds?</h3>
                    <p>Upon successful pickup of the return product at your doorstep, Myntra will instantly initiate the refund to your source account or chosen method of refund. Instant Refunds is not available in a few select pin codes and for all self ship returns.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="faq-content">
                    <img src="<?php echo base_url(); ?>image/icons/icon-1.png" class="img-fluid" />
                    <h3>How do I apply a coupon on my order?</h3>
                    <p>You can apply a coupon on cart page before order placement. The complete list of your unused and valid coupons will be available under “My Coupons” tab of App/Website/M-site.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="">
    <div class="container">
        <div class="still-que">
            <div class="row">
                <div class="col-md-6">
                    <h4>Still have questions?</h4>
                    <p>Can’t find the answer you’re looking for? Please chat to our friendly team.</p>
                </div>
                <div class="col-md-6">
                    <div class="typpeform">
                    <button (click)="loadTypeformScript()" data-bs-toggle="modal" data-bs-target="#getintouch"
                        class="btn">Get In Touch</button>


                    <!-- Modal -->
                    <div class="modal fade" id="getintouch" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div data-tf-live="01HKR5M3EDQN8045N0T90VSNP9"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
        // Change the title based on some condition or event
        document.getElementById("pageTitle").innerText = "FAQ";
    </script>
<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>