<?= $this->extend("layouts/app") ?>

<?= $this->section("body") ?>
<?php echo script_tag('js/jquery.min.js'); ?>
<?php echo script_tag('js/functions/Script.js'); ?>
<section class="home">
  <div class="container">
    <?php if (session()->getFlashdata('response') !== NULL) : ?>
      <p style="color:green; font-size:18px;">
        <?php echo session()->getFlashdata('response'); ?>
      </p>
    <?php endif; ?>
    <div class="text-center"><a class="crt-sur" href="<?php echo site_url('/order/createOrder'); ?>">Create Order</a>
    </div>
    <div class="mt-5 order-list-table">
      <?php if (!empty($orderList)) { ?>
        <table class="table mt-6 table-striped table-bordered">
          <thead>
            <tr class="sur-lis-bd">
              <th scope="col">S.No</th>
              <th scope="col" style="display:none;"> Id </th>
              <th scope="col">Order Id</th>
              <th scope="col">Item Id</th>
              <th scope="col">Customer Id</th>
              <th scope="col">Order date</th>
              <th scope="col">Item Description</th>
              <th scope="col">Quantity</th>
              <th scope="col">Status</th>
              <th scope="col">Due date</th>
              <th scope="col">Action</th>

            </tr>
          </thead>
          <tbody>
            <?php $count = 0;
            foreach ($orderList as $order) {
              $count++; ?>
              <tr id="orderRow">
                <td scope="row">
                  <?php echo $count; ?>
                </td>
                <td style="display:none;">
                  <?php echo stripslashes($order['order_list_id']); ?>
                  <button type="button" onclick="generateItemId()"></button>
                </td>
                <td>
                  <?php echo stripslashes($order['order_id']); ?>
                  <div id="item-button">
                    <button type="button" class="addItem" >AddItem +</button>
                  </div>
                </td>
                <td>
                  <?php echo stripslashes($order['item_id']); ?>
                </td>
                <td>
                  <?php echo stripslashes($order['customer_id']); ?>
                </td>
                <td>
                  <?php echo stripslashes($order['order_date']); ?>
                </td>
                <td>
                  <?php echo $order['type'] . " " . $order['colour'] . " " . $order['length'] . " " . $order['texture'] . " " . $order['ext_size']; ?>
                </td>
                <!-- <td>
              <?php echo stripslashes($order['colour']); ?>  
            </td>
            <td>
              <?php echo stripslashes($order['length']) ?>  
            </td>
            <td>
              <?php echo stripslashes($order['texture']); ?>  
            </td>
            <td>
              <?php echo stripslashes($order['ext_size']); ?>  
            </td> -->
                <td>
                  <?php echo stripslashes($order['quantity']) ?>
                </td>
                <td>
                  <?php echo stripslashes($order['status']); ?>
                </td>
                <td>
                  <?php echo stripslashes($order['due_date']); ?>
                </td>
                <td>
                  <button type="button" class="btn editOrder"> <img src="<?php echo base_url(); ?>images/icons/Create.png" class="img-centered img-fluid"></a>
                    <button type="button" class="btn  deleteOrder"><img src="<?php echo base_url(); ?>images/icons/remove.png" class="img-centered img-fluid"></a>

                </td>
                <!-- <td>
            </td> -->
              </tr>

            <?php } ?>
          </tbody>

        </table>
      <?php } else { ?>
    </div>
    <div class="text-center">
      <p class="fs-3"> <span class="text-danger">Oops!</span>No records found.</p>
    </div>
  <?php } ?>
  </div>
</section>
<script>
  $('.editOrder').on('click', function() {
    //getting data of selected row using id.

    console.log("ENtry");
    $id = document.getElementById('orderRow');
    console.log($id);
    $tr = $(this).closest('tr');
    var data = $tr.children().map(function() {
      return $(this).text();
    }).get();
    console.log(data[1].trim());
    var orderId = data[1].trim();
    var url = "<?= base_url('order/editOrder/') ?>" + orderId;
    window.location.href = url;

  });

  $('.deleteOrder').on('click', function() {
    //getting data of selected row using id.

    console.log("ENtry");
    $id = document.getElementById('orderRow');
    console.log($id);
    $tr = $(this).closest('tr');
    var data = $tr.children().map(function() {
      return $(this).text();
    }).get();
    console.log(data[1].trim());
    var orderId = data[1].trim();
    var url = "<?= base_url('order/deleteOrder') ?>";
    orderDelete(url, orderId);
  });


  $('.addItem').on('click', function() {
    //getting data of selected row using id.

    console.log("ENtry");
    $id = document.getElementById('orderRow');
    console.log($id);
    $tr = $(this).closest('tr');
    var data = $tr.children().map(function() {
      return $(this).text();
    }).get();
    console.log(data[2].trim());
    var orderId = data[2].trim();
    var url = "<?= base_url('order/generateItemId/') ?>"+ orderId;;
    window.location.href = url;
  });
</script>
<?= $this->endSection() ?>