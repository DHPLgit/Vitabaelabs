<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<section class="contact-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h1>Contact us</h1>
                <div class="contact-content">
                    <p>
                        Feel free to reach out to us at any time.<br/>
                        We value your feedback and inquiries.
                    </p>
                    <button (click)="loadTypeformScript()" class="contact-message" data-bs-toggle="modal" data-bs-target="#send-mess">Send
                        Message</button>
                    <!-- Modal -->
                    <div class="modal fade" id="send-mess" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div data-tf-live="01HKR5M3EDQN8045N0T90VSNP9"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="contact-content-2">
                    <!-- <p class=" d-none d-lg-block">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, Lorem ipsum dolor sit amet, consectetur
                        adipiscing elit, sed
                    </p> -->
                    <a href="#" class="contact-email  d-none d-lg-block">admin@vitabaelabs.in</a>
                    <div class="contact-details">
                        <div class="details">
                            <img src="<?php echo base_url(); ?>image/icons/Ringing-Phone.png" class="img-fluid" />
                            <p>+91 6383-287479</p>
                        </div>
                        <div class="details">
                            <img src="<?php echo base_url(); ?>image/icons/Shop-Location.png" class="img-fluid" />
                            <p>Chennai, India</p>
                        </div>
                        <div class="details  d-none d-lg-block">
                            <a href="https://www.instagram.com/thevitabae/"><img src="<?php echo base_url(); ?>image/icons/Instagram-Circle.png"
                                    class="img-fluid" /></a>
                            <a href="https://www.facebook.com/people/The-Vitabae/100068215744497/"><img src="<?php echo base_url(); ?>image/icons/Facebook-2.png" class="img-fluid" /></a>
                            <!-- <a href="#"><img src="<?php echo base_url(); ?>image/icons/YouTube-2.png" class="img-fluid" /></a> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="container">
        <div class="contact-content-2 d-lg-none">
            <!-- <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, Lorem ipsum dolor sit amet, consectetur
                adipiscing elit, sed
            </p> -->
            <a href="#" class="contact-email">admin@vitabaelabs.in</a>
            <div class="contact-details">
                <div class="details">
                    <a href="https://www.instagram.com/thevitabae/"><img src="<?php echo base_url(); ?>image/icons/Instagram-Circle.png"
                            class="img-fluid" /></a>
                    <a href="https://www.facebook.com/people/The-Vitabae/100068215744497/"><img src="<?php echo base_url(); ?>image/icons/Facebook-2.png" class="img-fluid" /></a>
                    <!-- <a href="#"><img src="<?php echo base_url(); ?>image/icons/YouTube-2.png" class="img-fluid" /></a> -->
                </div>

            </div>
        </div>
    </div>
</section>

<section class="accordion-contact">
    <div class="container">
        <div class="accordion-contact-detail">
            <h2>FAQ</h2>
            <div class="accordion accordion-flush" id="accordionExample">
                <div class="row">
                    <div class="col-md-6">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    How do I change my email?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can log in to your account and change it from your Profile.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    What should I do if my payment is declined?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    If your payment is declined, please contact our customer service. You may also need to contact your bank.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    What is your cancellation policy?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can now cancel an order prior to it shipping. Once an order has shipped, please contact our customer service team.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    How do I check order status?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Please check the “My Orders” section, in your account.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    How do I request a refund on an order?
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    For any order that has already been deliverd, please reach out to our customer service team, to proceed with a refund. Please also read our return policy.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                    How do I apply a coupon to my order?
                                </button>
                            </h2>
                            <div id="collapseSix" class="accordion-collapse collapse"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    You can apply a coupon on cart page before you place an order. If you are having any issue using a valid coupon, please contact our customer service team for assiatance.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <!-- <div #typeformEmbed></div> -->
    <!-- <div data-tf-live="01HK5KT6BEF2T6M0B89X2HX1K7"></div> -->
    <!-- <script src="//embed.typeform.com/next/embed.js"></script> -->
</section>
<script>
        // Change the title based on some condition or event
        document.getElementById("pageTitle").innerText = "Contact Us";
    </script>
<!-- <section class="contact-form">
    <div class="container">
        <div class="form">
            <form>
                <h2 class=" d-none d-lg-block">Send Us Your Feedback-<span>We Value your opinion</span></h2>
                <h2 class="d-lg-none">Send Us Your Feedback<br/><span>We Value your opinion</span></h2>
                <div class="row">
                    <div class=" col-md-6">
                        <div class="form-content">
                            <input type="text" placeholder="Name" class="name" />
                        </div>
                        <div class="form-content">
                            <input type="email" placeholder="Email" class="email" />
                        </div>
                    </div>
                    <div class=" col-md-6">
                        <div class="form-content">
                            <input type="tel" placeholder="Phone Number" class="phone" />
                        </div>
                        <div class="form-content">
                            <input type="text" placeholder="Subject" class="subject" />
                        </div>
                    </div>
                    <div class="form-content">
                        <input type="text" placeholder="Message" class="message" />
                    </div>
                    <div class="submit-btn-contact">
                        <button class="btn contact-message-btn">Send Message</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section> -->
<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>