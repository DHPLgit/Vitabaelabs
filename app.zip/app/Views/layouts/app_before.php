<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Google Tag Manager -->
  <script>(function (w, d, s, l, i) {
      w[l] = w[l] || []; w[l].push({
        'gtm.start':
          new Date().getTime(), event: 'gtm.js'
      }); var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
          'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-PSRGHBP5');</script>
  <!-- End Google Tag Manager -->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/x-icon" href="<?php echo base_url(); ?>image/logo/vitabae-new.png">
  <link rel="stylesheet" href="<?= base_url('bootstrap/css/bootstrap.min.css') ?>">
  <link rel="stylesheet" href="<?= base_url('css/front/vita.css') ?>">
  <!-- Owl Carousel CSS -->
  <link rel="stylesheet" href="<?= base_url('owl-carousel/assets/owl.carousel.min.css') ?>">
  <link rel="stylesheet" href="<?= base_url('owl-carousel/assets/owl.theme.default.min.css') ?>">
  <title id="pageTitle">Vitabae</title>
</head>

<body>
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PSRGHBP5" height="0" width="0"
      style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

  <div class="vitabae-menu" id="navbarmenu">
    <nav class="navbar navbar-expand-lg ">
      <div class="container-fluid">
        <a class="nav-link" href="/"><img class="img-fluid logo"
            src="<?php echo base_url(); ?>image/logo/logo.png" /></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar"
          aria-controls="mynavbar" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="mynavbar">
          <ul class="navbar-nav ">
            <li class="nav-item">
              <a class="nav-link" href="/blogs/index">Regenerative Farming</a>
            </li>
            <li class="nav-item">
              <a class="nav-link contact" href="/contact">Contact</a>
            </li>
            <li class="nav-item">
              <a class="nav-link contact" href="/signup">Signup</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </div>
  <?= $this->renderSection("body") ?>
  </div>

  <footer class="mt-5">
    <div class="container">
      <div class="row">
        <div class="col-md-3  col-sm-12 border-bg">
          <div class="foot-logo">
            <a href="#navbarmenu"><img src="<?php echo base_url(); ?>image/logo/v.png" class="img-fluid" alt=""></a>
          </div>
        </div>
        <!-- <div class="col-md-3 col-sm-12 border-bg">
              <div class="footer-menu">222
                  <ul>
                      <li>
                          <a href="">About</a>
                      </li>
                      <li>
                        <a href="">Research</a>
                      </li>
                      <li>
                        <a href="">Products</a>
                      </li>
                      <li>
                        <a href="">Medical Community</a>
                      </li>
                      <li>
                        <a href="">Join Our Community</a>
                      </li>
                  </ul> 
              </div>
          </div> -->
        <div class="col-md-6  col-sm-12 border-bg">
          <div class="footer-menu">
            <ul>
              <li>
                <a href="/signup">Signup</a>
              </li>

              <li>
                <a href="/askanything">FAQ</a>
              </li>
              <li>
                <a href="https://vitabaelabs.in/regenerative-farming/">Regenerative Farming</a>
              </li>
              <li>
                <a href="/contact">Contact Us</a>
              </li>
            </ul>
          </div>
        </div>
        <!-- <div class="col-md-3 col-sm-12 border-bg">

        </div> -->
        <div class="col-md-3 col-sm-12 ">
          <div class="foot-socialize">
            <h3>SOCIALIZE WITH VITABAE</h3>
            <div class="d-flex  justify-content-start">
              <a href="https://www.facebook.com/people/The-Vitabae/100068215744497/"><img
                  src="<?php echo base_url(); ?>image/icons/Facebook-2.png" class="img-fluid" /></a>
              <!-- <a href=""><img src="<?php echo base_url(); ?>image/icons/youtube.png"
                              class="img-fluid" /></a> -->
              <a href="https://www.instagram.com/thevitabae/"><img
                  src="<?php echo base_url(); ?>image/icons/instagram.png" class="img-fluid" /></a>
            </div>
            <div class="footer-form">
              <!-- <form>
                          <input type="email" placeholder="Email" id="foot-email" /><button
                              class="foot-btn">Submit</button>
                      </form> -->
            </div>
          </div>
        </div>
      </div>
      <div class="foot-description">
        <p>2024 © VITABAE LABS - ALL RIGHTS RESERVED </p>
      </div>
    </div>
  </footer>

</body>

<!-- JavaScript dependencies -->
<script src="<?= base_url('js/owl-carousel.js') ?>"></script>
<script src="<?= base_url('js/script.js') ?>"></script>
<?php echo script_tag('vendor/jquery/jquery.min.js'); ?>
<?php echo script_tag('vendor/jquery-easing/jquery.easing.min.js'); ?>
<script src="<?= base_url('bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<script src="//embed.typeform.com/next/embed.js"></script>
<!-- Owl Carousel JavaScript -->
<script src="<?= base_url('owl-carousel/owl.carousel.min.js') ?>"></script>

</body>

</html>