<?= $this->extend("layouts/app_before_blog") ?>
<?= $this->section("body") ?>
<?php echo script_tag('js/jquery-3.2.1.min.js'); ?>

<?= $this->section('meta') ?>
<meta name="description" class="metatags" content="<?= htmlspecialchars($blog['metadesc']); ?>">
<meta name="keywords" class="metatags" content="<?= htmlspecialchars($blog['metakey']); ?>">
<meta name="Author" class="metatags" content="<?= htmlspecialchars ($author) ?>">
<meta name="robots" class="metatags" content="<?= htmlspecialchars ($robots) ?>">
 <link rel="canonical" href="" id="canonical-link">
<title id="pageTitle"></title>
<?= $this->endSection() ?>


<section class="banner-blog">
    <img src="<?= 'http://vitabae.com/blogger/' . $blog['images']['image_fulltext'] ?>" class="img-fluid">

    <div class="author-detail-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-10">
                    <div class="banner-blog-details">
                        <!-- Title and Author -->
                        <h1><?= htmlspecialchars($blog['title']); ?></h1>
                        <div class="blog-head-tag-title">
                            <!-- Display fetched tags above the title -->
                            <?php if (!empty($tagsAboveTitle)): ?>
                                <div class="tag-list">
                                    <?php foreach ($tagsAboveTitle as $tag): ?>
                                        <span class="badge bg-secondary"><?= htmlspecialchars($tag['title']) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <div class="social-icons">
                                <div class="social-content">
                                    <a href="https://twitter.com/intent/tweet?url=<?= base_url('blogs/details/' . htmlspecialchars($blog['id'])); ?>"
                                        target="blank"><img src="<?php echo base_url(); ?>images/icons/twitter.svg"
                                            class="img-fluid" /></a>
                                    <a href="https://www.facebook.com/share/share.php?url=<?= base_url('blogs/details/' . htmlspecialchars($blog['id'])); ?>"
                                        target="blank"><img src="<?php echo base_url(); ?>images/icons/facebook.svg"
                                            class="img-fluid" /></a>
                                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= base_url('blogs/details/' . htmlspecialchars($blog['id'])); ?>"
                                        target="blank"><img src="<?php echo base_url(); ?>images/icons/mail.svg"
                                            class="img-fluid" /></a>
                                    <div class="copy-clipboard">
                                        <input type="button" value="" class="copy-to-clipboard" onclick="Copy();" />
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog-details">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-2">
                <p class="date-time-blog">
                    Published
                    <?= (new DateTime($blog['publish_up']))->format('m/d/Y'); ?>
                </p>
                <p class="date-time-blog">
                    Updated
                    <?= (new DateTime($blog['modified']))->format('m/d/Y') . ''; ?>
                </p>
                <p class="date-time-blog">
                    <?= htmlspecialchars($blog['read']) . '-minutes read!</b>'; ?>
                </p>
            </div>
            <div class="col-md-10">
                <div class="blog-details-content">
                    <p>
                        <?= nl2br($blog['introtext']); ?>
                    </p>
                    <input type="hidden" name="blog_Id" id="blog_Id" value="<?= $blog['id']; ?>" />
                </div>
                <hr class="horizontal-line-blog">
                </br>
                <div class="blog-head-tag-title">
                    <div class="blog-head-title-user-icon">
                        <img src="<?= 'https://vitabae.com/blogger/' . $blog['userimg'] ?>" alt="user author"
                            class="img-fluid" />
                            <p>By <?= htmlspecialchars($author) ?></p>
                    </div>
                    <div class="social-icons">
                        <div class="social-content">
                            <a href="https://twitter.com/intent/tweet?url=<?= base_url('blogs/details/' . htmlspecialchars($blog['id'])); ?>"
                                        target="blank"><img src="<?php echo base_url(); ?>images/icons/twitter.svg"
                                            class="img-fluid" /></a>
                                    <a href="https://www.facebook.com/sharer/sharer.php?url=<?= base_url('blogs/details/' . htmlspecialchars($blog['id'])); ?>"
                                        target="blank"><img src="<?php echo base_url(); ?>images/icons/facebook.svg"
                                            class="img-fluid" /></a>
                                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= base_url('blogs/details/' . htmlspecialchars($blog['id'])); ?>"
                                        target="blank"><img src="<?php echo base_url(); ?>images/icons/mail.svg"
                                            class="img-fluid" /></a>
                            <div class="copy-clipboard">
                                <input type="button" value="" class="copy-to-clipboard" onclick="Copy();" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="blog-details-list">
    <div class="container">
        <!-- Related Posts -->
        <div class="row mb-5">
            <div class="col-md-12">
                <h2 class="title">Related Posts</h2>
                <div class="row">
                    <?php foreach ($relatedPosts as $relatedPost): ?>
                        <?php
                        $relatedPostImages = $relatedPost['images'];
                        $relatedImagePath = isset($relatedPostImages['image_fulltext']) ? "https://vitabae.com/blogger/" . htmlspecialchars($relatedPostImages['image_fulltext']) : '';
                        ?>
                        <div class="col-sm-4">
                            <div class="related-post">
                                <div class="blog-list-img"><a
                                        href="<?= base_url('blogs/details/' . htmlspecialchars($relatedPost['id'])); ?>">
                                        <?php if ($relatedImagePath): ?>
                                            <img src="<?= $relatedImagePath ?>" class="img-fluid" alt="Related Post Image">
                                        <?php endif; ?></a>
                                </div>
                                <h3 class="title-head">
                                    
                                    <a
                                        href="<?= base_url('blogs/details/' . htmlspecialchars($relatedPost['id'])); ?>"><?= htmlspecialchars($relatedPost['title']); ?></a>
                                </h3>
                                <div class="related-post-author">
                                    <p>By <?= htmlspecialchars($relatedPost['author']) ?>, </p>&nbsp;
                                    <p class="date-time-blog">
                                        <?= isset($relatedPost['read']) ? htmlspecialchars($relatedPost['read']) . ' min read' : 'Read time not available'; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript">
   const pageUrl = window.location.href;
    console.log(pageUrl);
    function Copy() {

        navigator.clipboard.writeText(pageUrl).then(() => {
            alert('Page URL copied to clipboard!');

        }).catch(err => {
            console.error('Failed to copy URL: ', err);
        });
    }


    // Function to set the canonical link href to the current page URL
    function setCanonicalUrl() {
        const canonicalLink = document.getElementById('canonical-link');
        if (canonicalLink) {
            canonicalLink.href = pageUrl;
        }
    }

    // Call the function to set the canonical URL on page load
    window.onload = setCanonicalUrl;
</script>
<script>
    document.getElementById("pageTitle").innerText = '<?= htmlspecialchars($blog['browsertitle']); ?>';
</script>
<?= $this->endSection() ?>