<?= $this->extend("layouts/app_before_blog") ?>
<?= $this->section("body") ?>
<?php echo script_tag('js/jquery-3.2.1.min.js'); ?>

<?= $this->section('meta') ?>
<meta name="description" class="metatags" content="<?= htmlspecialchars($blog['metadesc']); ?>">
<meta name="keywords" class="metatags" content="<?= htmlspecialchars($blog['metakey']); ?>">
<meta name="Author" class="metatags" content="<?= htmlspecialchars($author) ?>">
<meta name="robots" class="metatags" content="<?= htmlspecialchars($robots) ?>">
<link rel="canonical" href="" id="canonical-link">
<title id="pageTitle"></title>
<?= $this->endSection() ?>


<section class="banner-blog">
    <img src="<?= 'https://vitabaelabs.in/adminblog/' . $blog['images']['image_fulltext'] ?>"
        alt="<?= htmlspecialchars($blog['images']['image_fulltext_alt']) ?>" class="img-fluid">

    <div class="author-detail-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-10">
                    <div class="banner-blog-details">
                        <!-- Title and Author -->
                        <h1><?= htmlspecialchars($blog['title']); ?></h1>
                        <div class="blog-head-tag-title">
                            <!-- Display fetched tags above the title -->
                            <?php if (!empty($tagsAboveTitle)): ?>
                                <div class="tag-list">
                                    <?php foreach ($tagsAboveTitle as $tag): ?>
                                        <span class="badge bg-secondary"><?= htmlspecialchars($tag['title']) ?></span>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <div class="social-icons">
                                <div class="social-content">
                                    <a href="https://twitter.com/intent/tweet?url=<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['id']); ?>"
                                        target="blank"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="24"
                                            viewBox="0 0 12 24" fill="none">
                                            <path
                                                d="M9.61944 3.91017H11.7679V0.165827C11.3972 0.114803 10.1225 0 8.63788 0C5.54025 0 3.41828 1.94969 3.41828 5.53312V8.83101H0V13.0169H3.41828V23.5494H7.60926V13.0179H10.8893L11.41 8.83199H7.60828V5.94817C7.60926 4.73833 7.93481 3.91017 9.61944 3.91017Z"
                                                fill="black" />
                                        </svg></a>
                                    <a href="https://www.facebook.com/share/share.php?url=<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['id']); ?>"
                                        target="blank"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="22"
                                            viewBox="0 0 25 22" fill="none">
                                            <path
                                                d="M19.689 0H23.5225L15.1474 9.31898L25 22H17.2855L11.2432 14.309L4.32946 22H0.493674L9.45161 12.0323L0 0H7.91033L13.372 7.02985L19.689 0ZM18.3435 19.7662H20.4677L6.7561 2.11651H4.47663L18.3435 19.7662Z"
                                                fill="black" />
                                        </svg></a>
                                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['id']); ?>"
                                        target="blank"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="28"
                                            viewBox="0 0 24 28" fill="none">
                                            <path
                                                d="M5.37214 24.4999H0.396429V8.14291H5.37214V24.4999ZM2.88161 5.91166C1.29054 5.91166 0 4.56635 0 2.94213C1.13882e-08 2.16196 0.303597 1.41374 0.844003 0.862075C1.38441 0.31041 2.11736 0.000488281 2.88161 0.000488281C3.64586 0.000488281 4.3788 0.31041 4.91921 0.862075C5.45962 1.41374 5.76321 2.16196 5.76321 2.94213C5.76321 4.56635 4.47214 5.91166 2.88161 5.91166ZM23.9946 24.4999H19.0296V16.5374C19.0296 14.6398 18.9921 12.2062 16.4427 12.2062C13.8557 12.2062 13.4593 14.2679 13.4593 16.4007V24.4999H8.48893V8.14291H13.2611V10.3742H13.3307C13.995 9.089 15.6177 7.73275 18.0386 7.73275C23.0743 7.73275 24 11.1179 24 15.5148V24.4999H23.9946Z"
                                                fill="black" />
                                        </svg></a>
                                    <div class="copy-clipboard">
                                        <input type="button" value="" class="copy-to-clipboard" onclick="Copy();" />
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog-details">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-2">
                <p class="date-time-blog">
                    Published
                    <?= (new DateTime($blog['publish_up']))->format('m/d/Y'); ?>
                </p>
                <p class="date-time-blog">
                    Updated
                    <?= (new DateTime($blog['modified']))->format('m/d/Y') . ''; ?>
                </p>
                <p class="date-time-blog">
                    <?= htmlspecialchars($blog['read']) . '-minutes read!</b>'; ?>
                </p>
            </div>
            <div class="col-md-10">
                <div class="blog-details-content" id="blog-details-content-id">
                    <p>
                        <?= nl2br($blog['introtext']); ?>
                    </p>

                    <input type="hidden" name="blog_Id" id="blog_Id" value="<?= $blog['id']; ?>" />
                </div>

                <div class="blog-head-tag-title">
                    <!-- <div class="blog-head-title-user-icon">
                        <img src="<?= 'https://vitabaelabs.in/adminblog/' . htmlspecialchars($blog['userimg'], ENT_QUOTES, 'UTF-8') ?>"
                            alt="user author" class="img-fluid" />

                         <img src="<?= 'https://vitabaelabs.in/adminblog/' . $blog['userimg'] ?>" alt="user author" class="img-fluid" />
                        <p>By <?= htmlspecialchars($author) ?></p>
                    </div> -->
                    <div class="social-icons">
                        <div class="social-content">
                            <a href="https://twitter.com/intent/tweet?url=<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['id']); ?>"
                                target="blank"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="24"
                                            viewBox="0 0 12 24" fill="none">
                                            <path
                                                d="M9.61944 3.91017H11.7679V0.165827C11.3972 0.114803 10.1225 0 8.63788 0C5.54025 0 3.41828 1.94969 3.41828 5.53312V8.83101H0V13.0169H3.41828V23.5494H7.60926V13.0179H10.8893L11.41 8.83199H7.60828V5.94817C7.60926 4.73833 7.93481 3.91017 9.61944 3.91017Z"
                                                fill="black" />
                                        </svg></a>
                            <a href="https://www.facebook.com/sharer/sharer.php?url=<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['id']); ?>"
                                target="blank"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="22"
                                            viewBox="0 0 25 22" fill="none">
                                            <path
                                                d="M19.689 0H23.5225L15.1474 9.31898L25 22H17.2855L11.2432 14.309L4.32946 22H0.493674L9.45161 12.0323L0 0H7.91033L13.372 7.02985L19.689 0ZM18.3435 19.7662H20.4677L6.7561 2.11651H4.47663L18.3435 19.7662Z"
                                                fill="black" />
                                        </svg></a>
                            <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($blog['id']); ?>"
                                target="blank"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="28"
                                            viewBox="0 0 24 28" fill="none">
                                            <path
                                                d="M5.37214 24.4999H0.396429V8.14291H5.37214V24.4999ZM2.88161 5.91166C1.29054 5.91166 0 4.56635 0 2.94213C1.13882e-08 2.16196 0.303597 1.41374 0.844003 0.862075C1.38441 0.31041 2.11736 0.000488281 2.88161 0.000488281C3.64586 0.000488281 4.3788 0.31041 4.91921 0.862075C5.45962 1.41374 5.76321 2.16196 5.76321 2.94213C5.76321 4.56635 4.47214 5.91166 2.88161 5.91166ZM23.9946 24.4999H19.0296V16.5374C19.0296 14.6398 18.9921 12.2062 16.4427 12.2062C13.8557 12.2062 13.4593 14.2679 13.4593 16.4007V24.4999H8.48893V8.14291H13.2611V10.3742H13.3307C13.995 9.089 15.6177 7.73275 18.0386 7.73275C23.0743 7.73275 24 11.1179 24 15.5148V24.4999H23.9946Z"
                                                fill="black" />
                                        </svg></a>
                            <div class="copy-clipboard">
                                <input type="button" value="" class="copy-to-clipboard" onclick="Copy();" />
                            </div>
                        </div>
                    </div>
                </div>
                <hr class="horizontal-line-blog">
                </br>
                <div class="blog-head-tag-title">
                    <div class="blog-head-title-user-icon md d-none d-md-block">

                        <img loading="lazy" width="133" height="140"
                            src="<?= !empty($blog['userimg']) ? 'https://vitabaelabs.in/adminblog/' . htmlspecialchars($blog['userimg'], ENT_QUOTES, 'UTF-8') : 'https://vitabaelabs.in/adminblog/images/banners/portrait-of-girl-with-beautiful-long-hair-isolated-on-white-background-portrait-of-young-woman-without-face-avatar-for-social-network-mobile-app-minimalist-vector.png#joomlaImage://local-images/banners/portrait-of-girl-with-beautiful-long-hair-isolated-on-white-background-portrait-of-young-woman-without-face-avatar-for-social-network-mobile-app-minimalist-vector.png?width=139&height=146' ?>"
                            alt="user author" class="img-fluid" />

                        <p class="author-name"><span><?= htmlspecialchars($author) ?><br /></span></p>
                        <a href="<?= $blog['linkedIn']; ?>" class="author-linkin">LinkedIn</a>
                        <p><?= $blog['authorDescription']; ?></p>
                    </div>
                    <div class="blog-head-title-user-icon sm d-md-none">
                        <div class="blog-author-first-head">
                            <img src="<?= 'https://vitabaelabs.in/adminblog/' . htmlspecialchars($blog['userimg'], ENT_QUOTES, 'UTF-8') ?>"
                                alt="user author" class="img-fluid" />
                            <p class="author-name"><span><?= htmlspecialchars($author) ?><br /></span><a
                                    href="<?= $blog['linkedIn']; ?>" class="author-linkin">LinkedIn</a></p>
                        </div>
                        <p><?= $blog['authorDescription']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="blog-details-list">
    <div class="container">
        <!-- Related Posts -->
        <div class="row mb-5">
            <div class="col-md-12">
                <h2 class="title">Related Posts</h2>
                <div class="row">
                    <?php foreach ($relatedPosts as $relatedPost): ?>
                        <?php
                        $relatedPostImages = $relatedPost['images'];
                        $relatedImagePath = isset($relatedPostImages['image_fulltext']) ? "https://vitabaelabs.in/adminblog/" . htmlspecialchars($relatedPostImages['image_fulltext']) : '';
                        ?>
                        <div class="col-sm-4">
                            <div class="related-post">
                                <div class="blog-list-img"><a
                                        href="<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($relatedPost['additional_value']); ?>">
                                        <?php if ($relatedImagePath): ?>
                                            <img src="<?= $relatedImagePath ?>"
                                                alt="<?= htmlspecialchars($relatedPost['images']['image_intro_alt']) ?>"
                                                class="img-fluid">
                                        <?php endif; ?></a>
                                </div>
                                <h3 class="title-head">

                                    <a
                                        href="<?= 'https://www.vitabaelabs.in/blogs/' . htmlspecialchars($relatedPost['additional_value']); ?>"><?= htmlspecialchars($relatedPost['title']); ?></a>
                                </h3>
                                <div class="related-post-author">
                                    <p>By <?= htmlspecialchars($relatedPost['author']) ?>, </p>&nbsp;
                                    <p class="date-time-blog">
                                        <?= isset($relatedPost['read']) ? htmlspecialchars($relatedPost['read']) . ' min read' : 'Read time not available'; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="application/ld+json"><?= $blog['articles']; ?></script>
<script type="application/ld+json"><?= $blog['blog_posting']; ?></script>
<script type="application/ld+json"><?= $blog['faq']; ?></script>
<script type="text/javascript">
    const pageUrl = window.location.href;
    console.log(pageUrl);
    function Copy() {

        navigator.clipboard.writeText(pageUrl).then(() => {
            alert('Page URL copied to clipboard!');

        }).catch(err => {
            console.error('Failed to copy URL: ', err);
        });
    }


    // Function to set the canonical link href to the current page URL
    function setCanonicalUrl() {
        const canonicalLink = document.getElementById('canonical-link');
        if (canonicalLink) {
            canonicalLink.href = pageUrl;
        }
    }

    // Call the function to set the canonical URL on page load
    window.onload = setCanonicalUrl;
</script>
<script>
    document.getElementById("pageTitle").innerText = '<?= htmlspecialchars($blog['browsertitle']); ?>';
    
    
    
    document.addEventListener("DOMContentLoaded", function () {
    // Base URL to be added
    const baseUrl = "https://vitabaelabs.in/adminblog/";

    // Select the blog details container
    const blogContent = document.getElementById("blog-details-content-id");

    if (blogContent) {
        // Select all image tags inside the blog content
        const images = blogContent.getElementsByTagName("img");

        for (let img of images) {
            if (img.src && !img.src.startsWith(baseUrl)) {
                img.src = baseUrl + img.getAttribute("src");
            }
        }
    }
});

</script>
<?= $this->endSection() ?>