<?= $this->extend("layouts/app_before") ?>
<?= $this->section("body") ?>
<section class="signup">
    <div class="container">
        <div class="sign-up-form">
            <form>
                <h1>Create your account</h1>
                <input type="text" placeholder="Email Address" class="email" /><br />
                <button class="submit">Continue</button><br />
                <a href="/contactus" class="help">How can we help?
                </a>
                <div class="or">
                    <h2><span>OR</span></h2>
                </div>
                <div class="icons">
                    <a class="g-btn"><img src="<?php echo base_url(); ?>image/icons/Google.png" />Continue with Google</a>
                </div>
                <div class="icons">
                    <a class="g-btn"><img src="<?php echo base_url(); ?>image/icons/Microsoft.png" />Continue with
                        MicroSoft
                        Account</a></div>
                <div class="icons">
                    <a class="g-btn"><img src="<?php echo base_url(); ?>image/icons/apple.png" />Continue with
                        Apple</a>
                </div>
            </form>
            
        </div>
    </div>
</section>
<script>
        // Change the title based on some condition or event
        document.getElementById("pageTitle").innerText = "Signup";
    </script>
<?php echo script_tag('js/jquery.min.js'); ?>
<?= $this->endSection() ?>