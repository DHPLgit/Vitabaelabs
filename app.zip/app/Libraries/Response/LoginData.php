<?php

namespace App\Libraries\Response;

class LoginData
{

    public string $token;

    public array  $accessPages;
}
