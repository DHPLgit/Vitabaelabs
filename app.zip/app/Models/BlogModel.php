<?php

namespace App\Models;

use CodeIgniter\Model;

class BlogModel extends Model {
    protected $table = 'vb_content';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'introtext', 'created', 'author', 'images', 'metadata', 'modified', 'publish_up'];

    public function getBlogsFilteredByTags($tags)
    {
        if (empty($tags)) {
            // No tags selected, return all blogs
            return $this->findAll();
        }
        // Build query to fetch blogs matching all selected tags
        $builder = $this->db->table('vb_content c');
        $builder->select('c.id, c.title, c.introtext, c.fulltext, c.created, c.modified, c.images, c.metadesc, c.metadata, c.catid, c.state, c.featured, c.language, c.access, c.ordering');
        $builder->distinct();

        // Join with tag mapping and tag tables
        $builder->join('vb_contentitem_tag_map tm', 'c.id = tm.content_item_id');
        $builder->join('vb_tags t', 'tm.tag_id = t.id');

        // Apply WHERE conditions for each tag
        foreach ($tags as $tagId) {
            $builder->where("tm.tag_id", $tagId);
        }

        // Execute query and return results as array
        $query = $builder->get();
        return $query->getResultArray();
    }
    // Fetch blogs based on selected tags
public function getBlogs($tag_ids = []) {
        $builder = $this->db->table($this->table)
                            ->select('vb_content.*, vb_fields_values.value as read')
                            ->join('vb_contentitem_tag_map', 'vb_content.id = vb_contentitem_tag_map.content_item_id')
                            ->join('vb_fields_values', 'vb_content.id = vb_fields_values.item_id', 'left')
                            ->whereIn('vb_fields_values.field_id', [1,3])
                            ->where('vb_content.state', 1) // Filter by state = 1
                            ->orderBy('vb_content.created', 'DESC');
    
        if (!empty($tag_ids)) {
            $builder->whereIn('vb_contentitem_tag_map.tag_id', $tag_ids)
                    ->groupBy('vb_content.id')
                    ->having('COUNT(DISTINCT vb_contentitem_tag_map.tag_id) =', count($tag_ids), false);
        } else {
            $builder->groupBy('vb_content.id');
        }
        $blogs = $builder->get()->getResultArray();
    
        // Debugging output
        foreach ($blogs as $blog) {
            if (!isset($blog['id'])) {
                var_dump($blog);
            }
        }
    
        return $blogs;
    }

   // Fetch a single blog
//    public function getBlog($id) {
//                  $blog = $this->select('vb_content.*, vfv1.value as read, vfv1.value as additional_value, vfv1.field_id, vfv1.value')
//                             ->join('vb_fields_values vfv1', 'vb_content.id = vfv1.item_id', 'left')
//                             ->whereIn('vfv1.field_id', [1,9,11,12])
//                             ->where('vb_content.id', $id)
//                             ->findAll();

//     return $blog;
// }
    // Fetch related posts
    public function getRelatedPosts($currentBlogId, $limit = 3) {
                             $builder = $this->db->table('vb_content');
                             $builder->select('vb_content.*, vfv1.value as read, vfv2.value as additional_value');
                             $builder->join('vb_fields_values vfv1', 'vb_content.id = vfv1.item_id AND vfv1.field_id = 1', 'left');
                             $builder->join('vb_fields_values vfv2', 'vb_content.id = vfv2.item_id AND vfv2.field_id = 12', 'left');
                             $builder->where('vb_content.id !=', $currentBlogId);
                             $builder->orderBy('vb_content.created', 'DESC');
                             $builder->where('vb_content.state', 1);
                             $relatedPosts = $builder->limit($limit)->get()->getResultArray();

        foreach ($relatedPosts as &$post) {
            // Decode JSON formatted image data if it's a string
            if (is_string($post['images'])) {
                $post['images'] = json_decode($post['images'], true);
            }
            // Decode metadata JSON and extract author
            if (is_string($post['metadata'])) {
                $metadata = json_decode($post['metadata'], true);
                $post['author'] = $metadata['author'] ?? 'Author not available';
            } else {
                $post['author'] = 'Author not available';
            }
            // Ensure read and additional_value have default values
            $post['read'] = $post['read'] ?? '0';
            $post['additional_value'] = $post['additional_value'] ?? 'No additional value';
        }
        return $relatedPosts;
    }
    public function getTodaysPick($limit = 3) {
                           $builder = $this->db->table('vb_content');
                           $builder->select('vb_content.*, vfv1.value as read, vfv2.value as additional_value');
                           $builder->join('vb_fields_values vfv1', 'vb_content.id = vfv1.item_id AND vfv1.field_id = 1', 'left');
                           $builder->join('vb_fields_values vfv2', 'vb_content.id = vfv2.item_id AND vfv2.field_id = 12', 'left');
                           $builder->orderBy('vb_content.created', 'DESC');
                           $builder->where('vb_content.state', 1);
                           $todaysPick = $builder->limit($limit)->get()->getResultArray();
        foreach ($todaysPick as &$pick) {
            // Decode JSON formatted image data if it's a string
            if (is_string($pick['images'])) {
                $pick['images'] = json_decode($pick['images'], true);
            }
            // Decode metadata JSON and extract author
            if (is_string($pick['metadata'])) {
                $metadata = json_decode($pick['metadata'], true);
                $pick['author'] = $metadata['author'] ?? 'Author not available';
            } else {
                $pick['author'] = 'Author not available';
            }
            

            // Ensure read and additional_value have default values

            $pick['read'] = $pick['read'] ?? '0';

            $pick['additional_value'] = $pick['additional_value'] ?? 'No additional value';
        }

        return $todaysPick;
    }

    public function getFieldValue($item_id, $field_id)
    {
        $builder = $this->db->table('vb_fields_values')
                            ->select('value')
                            ->where('item_id', $item_id)
                            ->where('field_id', $field_id);

        $query = $builder->get();
        $result = $query->getRowArray();
        // print_r($result);

        return $result ? $result['value'] : null;
    }

public function getBlogByAdditionalValue($additionalValue)
{
    return $this->select('vb_content.*, vfv1.value as read, vfv2.value as additional_value, vfv3.value as articles, vfv4.value as blog_posting, vfv5.value as faq, vfv6.value as userimg, vfv7.value as authorDescription, vfv8.value as linkedIn')
                ->join('vb_fields_values vfv1', 'vb_content.id = vfv1.item_id AND vfv1.field_id = 1', 'left')
                ->join('vb_fields_values vfv2', 'vb_content.id = vfv2.item_id AND vfv2.field_id = 12', 'left')
                ->join('vb_fields_values vfv3', 'vb_content.id = vfv3.item_id AND vfv3.field_id = 14', 'left')
                ->join('vb_fields_values vfv4', 'vb_content.id = vfv4.item_id AND vfv4.field_id = 15', 'left')
                ->join('vb_fields_values vfv5', 'vb_content.id = vfv5.item_id AND vfv5.field_id = 16', 'left')
                ->join('vb_fields_values vfv6', 'vb_content.id = vfv6.item_id AND vfv6.field_id = 9', 'left')
                ->join('vb_fields_values vfv7', 'vb_content.id = vfv7.item_id AND vfv7.field_id = 17', 'left') // Fetch userimg if field_id is 9
                ->join('vb_fields_values vfv8', 'vb_content.id = vfv8.item_id AND vfv8.field_id = 18', 'left')
                ->where('vfv2.value', $additionalValue)
                ->first();
}

public function getBlog($id) {
    $builder = $this->db->table('vb_content')
                        ->select('vb_content.*, vfv1.value as read, vfv2.value as additional_value, vfv3.value as articles, vfv4.value as blog_posting, vfv5.value as faq, vfv6.value as browsertitle, vfv7.value as userimg, vfv8.value as authorDescription, vfv9.value as linkedIn')
                        ->join('vb_fields_values vfv1', 'vb_content.id = vfv1.item_id AND vfv1.field_id = 1', 'left')
                        ->join('vb_fields_values vfv2', 'vb_content.id = vfv2.item_id AND vfv2.field_id = 12', 'left')
                        ->join('vb_fields_values vfv3', 'vb_content.id = vfv3.item_id AND vfv3.field_id = 14', 'left')
                        ->join('vb_fields_values vfv4', 'vb_content.id = vfv4.item_id AND vfv4.field_id = 15', 'left')
                        ->join('vb_fields_values vfv5', 'vb_content.id = vfv5.item_id AND vfv5.field_id = 16', 'left')
                        ->join('vb_fields_values vfv6', 'vb_content.id = vfv6.item_id AND vfv6.field_id = 11', 'left') // Ensure correct field_id for browsertitle
                        ->join('vb_fields_values vfv7', 'vb_content.id = vfv7.item_id AND vfv7.field_id = 9', 'left')
                        ->join('vb_fields_values vfv8', 'vb_content.id = vfv8.item_id AND vfv8.field_id = 17', 'left') // Fetch userimg if field_id is 9
                        ->join('vb_fields_values vfv9', 'vb_content.id = vfv9.item_id AND vfv9.field_id = 18', 'left') 
                        ->where('vb_content.id', $id);

    $query = $builder->get(); // Use get() to execute the query  
    $result = $query->getRowArray(); // Fetch the result as an associative array

    return $result;
}




}
