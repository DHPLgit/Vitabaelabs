<?php

namespace App\Models;

use CodeIgniter\Model;

class CommentModel extends Model
{
    protected $table = 'comments';
    protected $primaryKey = 'comment_id';
    protected $allowedFields = ['blog_id', 'parent_id', 'name', 'comment', 'created_at', 'updated_at', 'status', 'approved_by'];
    protected $useTimestamps = true;
    protected $returnType = 'array';
    public function insertComment($blogId, $parent_id, $commentContent)
    {
        $data = [
            'blog_id' => $blogId,
            'parent_id' => $parent_id,
            'comment' => $commentContent
        ];

        return $this->insert($data);
    }

    public function getCommentsByBlogId($blogId)
    {
        if (!is_numeric($blogId)) {
            return [];
        }
        $query = $this->select('*')
            ->where('blog_id', $blogId)
            ->where('status', '0')
            ->orderBy('parent_id', 'ASC')
            ->orderBy('comment_id', 'ASC')
            ->get();

        $comments = $query->getResult();
        return $comments;
    }

    public function insertReply($parentCommentId, $name, $commentContent)
    {
        $data = [
            'parent_id' => $parentCommentId,
            'name' => $name,
            'comment' => $commentContent,
            'status' => 'Pending', // Set the status to 'Pending' for the reply
        ];

        return $this->insert($data);
    }

    public function getRepliesByParentId($parentId)
    {
        if (!is_numeric($parentId)) {
            return [];
        }
        $query = $this->select('*')
            ->where('parent_id', $parentId)
            ->orderBy('parent_id', 'ASC')
            ->orderBy('comment_id', 'ASC')
            ->get();

            // echo "<pre>";
            // echo $this->getLastQuery(); // Get the last executed query for debugging
            // echo "</pre>";
        $replies = $query->getResult();
        return $replies;
    }
}
