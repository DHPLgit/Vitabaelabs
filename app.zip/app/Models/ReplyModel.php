<?php

namespace App\Models;

use CodeIgniter\Model;

class ReplyModel extends Model
{
    protected $table = 'replies';
    protected $primaryKey = 'id';
    protected $allowedFields = ['comment_id', 'name', 'content'];

    // Method to fetch replies for a specific comment
    // public function getRepliesForComment($commentId)
    // {
    //     return $this->where('comment_id', $commentId)->findAll();
    // }

    // ReplyModel.php
    public function getRepliesForComment($comment)
    {
        $commentId = $comment['id'];

        return $this->where('comment_id', $commentId)->findAll();
    }

}
