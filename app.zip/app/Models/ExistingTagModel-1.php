<?php

namespace App\Models;

use CodeIgniter\Model;

class ExistingTagModel extends Model {
    protected $table = 'vb_tags';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'path'];

    public function getAllTagsWithCount() {
        $tags = $this->select('id, title, path')
                     ->findAll();

        return $tags;
    }

    public function getTagsByContentId($content_id)
    {
        $query = $this->db->table('vb_contentitem_tag_map tm')
                          ->select('t.title, t.path')
                          ->join('vb_tags t', 'tm.tag_id = t.id')
                          ->where('tm.content_item_id', $content_id)
                          ->get();

        return $query->getResultArray();
    }
    public function getTagsGroupedByHeader() {
        $tags = $this->select('id, title, path')
                     ->where('path !=', '') // Exclude tags where path is empty
                     ->findAll();
    
        $groupedTags = [];
        foreach ($tags as $tag) {
            // Split the path into header and inner value
            if (strpos($tag['path'], '/') !== false) {
                list($header, $innerValue) = explode('/', $tag['path'], 2);
                if (!empty($innerValue)) { // Check if innerValue is not empty
                    $groupedTags[$header][$innerValue] = [
                        'id' => $tag['id'],
                        'title' => $tag['title'],
                        'innerValue' => $innerValue
                    ];
                }
            } else {
                // If no slash is found, treat the whole path as the header
                $groupedTags[$tag['path']][] = [
                    'id' => $tag['id'],
                    'title' => $tag['title'],
                    'innerValue' => '' // No inner value since there's no slash
                ];
            }
        }
        return $groupedTags;
    }
    
}
