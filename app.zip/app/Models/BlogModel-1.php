<?php

namespace App\Models;

use CodeIgniter\Model;

class BlogModel extends Model {
    protected $table = 'vb_content';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'introtext', 'created', 'author', 'images', 'metadata', 'modified', 'publish_up', ];

    public function getBlogsFilteredByTags($tags)
    {
        if (empty($tags)) {
            // No tags selected, return all blogs
            return $this->findAll();
        }

        // Build query to fetch blogs matching all selected tags
        $builder = $this->db->table('vb_content c');
        $builder->select('c.id, c.title, c.introtext, c.fulltext, c.created, c.modified, c.images, c.metadesc, c.metadata, c.catid, c.state, c.featured, c.language, c.access, c.ordering');
        $builder->distinct();

        // Join with tag mapping and tag tables
        $builder->join('vb_contentitem_tag_map tm', 'c.id = tm.content_item_id');
        $builder->join('vb_tags t', 'tm.tag_id = t.id');

        // Apply WHERE conditions for each tag
        foreach ($tags as $tagId) {
            $builder->where("tm.tag_id", $tagId);
        }

        // Execute query and return results as array
        $query = $builder->get();
        return $query->getResultArray();
    }
    // Fetch blogs based on selected tags
    public function getBlogs($tag_ids = []) {
        $builder = $this->db->table($this->table)
                            ->select('vb_content.*, vb_fields_values.value as read')
                            ->join('vb_contentitem_tag_map', 'vb_content.id = vb_contentitem_tag_map.content_item_id')
                            ->join('vb_fields_values', 'vb_content.id = vb_fields_values.item_id', 'left')
                            ->whereIn('vb_fields_values.field_id', [1,3]);

        if (!empty($tag_ids)) {
            $builder->whereIn('vb_contentitem_tag_map.tag_id', $tag_ids)
                    ->groupBy('vb_content.id')
                    ->having('COUNT(DISTINCT vb_contentitem_tag_map.tag_id) =', count($tag_ids), false);
        } else {
            $builder->groupBy('vb_content.id');
        }

        $blogs = $builder->get()->getResultArray();

        // Debugging output
        foreach ($blogs as $blog) {
            if (!isset($blog['id'])) {
                var_dump($blog);
            }
        }
        return $blogs;
    }

   // Fetch a single blog
   public function getBlog($id) {
    $blog = $this->select('vb_content.*, vb_fields_values.field_id, vb_fields_values.value')
                 ->join('vb_fields_values', 'vb_content.id = vb_fields_values.item_id', 'left')
                 //->whereIn('vb_fields_values.field_id', [1,3])
                 ->where('vb_content.id', $id)
                 //->groupBy('vb_content.id')
                 ->findAll();

    // Debugging output
    // if (!isset($blog['id'])) {
    //     var_dump($blog);
    // }

    return $blog;
}

    // Fetch related posts
    public function getRelatedPosts($currentBlogId, $limit = 3) {
        $relatedPosts = $this->select('vb_content.*, vb_fields_values.value as read')
                             ->join('vb_fields_values', 'vb_content.id = vb_fields_values.item_id', 'left')
                             ->whereIn('vb_fields_values.field_id', [1])
                             ->where('vb_content.id !=', $currentBlogId)
                             ->orderBy('vb_content.created', 'DESC')
                             ->findAll($limit);

        foreach ($relatedPosts as &$post) {
            // Decode JSON formatted image data if it's a string
            if (is_string($post['images'])) {
                $post['images'] = json_decode($post['images'], true);
            }
            // Decode metadata JSON and extract author
            if (is_string($post['metadata'])) {
                $metadata = json_decode($post['metadata'], true);
                $post['author'] = $metadata['author'] ?? 'Author not available';
            } else {
                $post['author'] = 'Author not available';
            }
        }
        return $relatedPosts;
    }
    public function getTodaysPick($limit = 3) {
        $todaysPick = $this->select('vb_content.*, vb_fields_values.value as read')
                           ->join('vb_fields_values', 'vb_content.id = vb_fields_values.item_id', 'left')
                           ->whereIn('vb_fields_values.field_id', [1])
                           ->orderBy('vb_content.created', 'DESC')
                           ->findAll($limit);

        foreach ($todaysPick as &$pick) {
            // Decode JSON formatted image data if it's a string
            if (is_string($pick['images'])) {
                $pick['images'] = json_decode($pick['images'], true);
            }
            // Decode metadata JSON and extract author
            if (is_string($pick['metadata'])) {
                $metadata = json_decode($pick['metadata'], true);
                $pick['author'] = $metadata['author'] ?? 'Author not available';
            } else {
                $pick['author'] = 'Author not available';
            }
        }

        return $todaysPick;
    }

}
