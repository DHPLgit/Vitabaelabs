var totalLikes = 0;
var totalUnlikes = 0;

function postReply(commentId) {
	$('#commentId').val(commentId);
	$("#comment").focus();
}

$("#submitButton").click(function () {
	$("#comment-message").css('display', 'none');
	var str = $("#frm-comment").serialize();

	$.ajax({
		url: "http://localhost:8080/blogs/addComment",
		data: str,
		type: 'post',
		success: function (response) {
			var result = eval('(' + response + ')');
			if (response) {
				$("#comment-message").css('display', 'inline-block');
				$("#comment").val("");
				$("#commentId").val("");
				listComment();
			} else {
				alert("Failed to add comments !");
				return false;
			}
		}
	});
});

$(document).ready(function () {
	var blogId = $("#blog_Id").val();
	listComment(blogId);
});

function listComment(blogId) {
	$.post("http://localhost:8080/blogs/replies/" + blogId,
		function (data) {
			var data = JSON.parse(data);
			var comments = "";
			var replies = "";
			var item = "";
			var parent = -1;like_icon=0;
			var results = new Array();

			var list = $("<ul class='outer-comment'>");
			var item = $("<li>").html(comments);
			data['comments'].forEach((item) => {
				var commentId = item['comment_id'];
				parent = item['parent_id'];

			//	var obj = getLikesUnlikes(commentId);

				if (parent == "0") {
					// if (data[i]['like_unlike'] >= 1) {
					// 	like_icon = "<img src='assets/images/like.png'  id='unlike_" + item['comment_id'] +
					// 		"' class='like-unlike'  onClick='likeOrDislike(" + item['comment_id'] + ",-1)' />";
					// 	like_icon += "<img style='display:none;' src='assets/images/unlike.png' id='like_" + item['comment_id'] +
					// 		"' class='like-unlike' onClick='likeOrDislike(" + item['comment_id'] + ",1)' />";
					// } else {
					// 	like_icon = "<img style='display:none;' src='assets/images/like.png'  id='unlike_" + item['comment_id'] +
					// 		"' class='like-unlike'  onClick='likeOrDislike(" + item['comment_id'] + ",-1)' />";
					// 	like_icon += "<img src='assets/images/unlike.png' id='like_" + item['comment_id'] +
					// 		"' class='like-unlike' onClick='likeOrDislike(" + item['comment_id'] + ",1)' />";
					// }

					comments =
						"\
                                        <div class='comment-row'>\
                                            <div class='comment-info'>\
                                                <span class='commet-row-label'>from</span>\
                                                <span class='posted-by'>" +
						item['comment_sender_name'] +
						"</span>\
                                                <span class='commet-row-label'>at</span> \
                                                <span class='posted-at'>" +
						item['date'] +
						"</span>\
                                            </div>\
                                            <div class='comment-text'>" +
						item['comment'] +
						"</div>\
                                            <div>\
                                                <a class='btn-reply' onClick='postReply(" +
						commentId +
						")'>Reply</a>\
                                            </div>\
                                            <div class='post-action'>\ " +
						like_icon + "&nbsp;\
                                                <span id='likes_" + commentId + "'> " +
						totalLikes +
						" likes </span>\
                                            </div>\
                                        </div>";

					var item = $("<li>").html(comments);
					list.append(item);
					var reply_list = $('<ul>');
					item.append(reply_list);
					listReplies(commentId, data['comments'], reply_list);
				}
			});
			$("#output").html(list);
		}).fail(function(xhr, status, error) {
			console.error("AJAX Error:", status, error);
		});
}

function listReplies(commentId, data, list) {
data.forEach((itemComment) => {

		//var obj = getLikesUnlikes(item.comment_id);
		if (commentId == itemComment['parent_id']) {
			// if (item['like_unlike'] >= 1) {
			// 	like_icon = "<img src='assets/images/like.png'  id='unlike_" + item['comment_id'] +
			// 		"' class='like-unlike'  onClick='likeOrDislike(" + item['comment_id'] + ",-1)' />";
			// 	like_icon += "<img style='display:none;' src='assets/images/unlike.png' id='like_" + item['comment_id'] +
			// 		"' class='like-unlike' onClick='likeOrDislike(" + item['comment_id'] + ",1)' />";

			// } else {
			// 	like_icon = "<img style='display:none;' src='assets/images/like.png'  id='unlike_" + item['comment_id'] +
			// 		"' class='like-unlike'  onClick='likeOrDislike(" + item['comment_id'] + ",-1)' />";
			// 	like_icon += "<img src='assets/images/unlike.png' id='like_" + item['comment_id'] +
			// 		"' class='like-unlike' onClick='likeOrDislike(" + item['comment_id'] + ",1)' />";

			// }
			var comments =
				"\
                                        <div class='comment-row'>\
                                            <div class='comment-info'>\
                                                <span class='commet-row-label'>from</span>\
                                                <span class='posted-by'>" +
												itemComment['comment_sender_name'] +
				"</span>\
                                                <span class='commet-row-label'>at</span> \
                                                <span class='posted-at'>" +
												itemComment['date'] +
				"</span>\
                                            </div>\
                                            <div class='comment-text'>" +
											itemComment['comment'] +
				"</div>\
                                            <div>\
                                                <a class='btn-reply' onClick='postReply(" +
												itemComment['comment_id'] +
				")'>Reply</a>\
                                            </div>\
                                            <div class='post-action'> " +
				  + "&nbsp;\
                                                <span id='likes_" + itemComment['comment_id'] +
				"'> " + totalLikes +
				" likes </span>\
                                            </div>\
                                        </div>";

			var item = $("<li>").html(comments);
			var reply_list = $('<ul>');
			list.append(item);
			item.append(reply_list);
			listReplies(itemComment['comment_id'], data, reply_list);
		}
	}
);
}

function getLikesUnlikes(commentId) {

	$.ajax({
		type: 'POST',
		async: false,
		url: 'get-like-unlike.php',
		data: {
			comment_id: commentId
		},
		success: function (data) {
			totalLikes = data;
		}

	});

}


function likeOrDislike(comment_id, like_unlike) {

	$.ajax({
		url: 'comment-like-unlike.php',
		async: false,
		type: 'post',
		data: {
			comment_id: comment_id,
			like_unlike: like_unlike
		},
		dataType: 'json',
		success: function (data) {

			$("#likes_" + comment_id).text(data + " likes");

			if (like_unlike == 1) {
				$("#like_" + comment_id).css("display", "none");
				$("#unlike_" + comment_id).show();
			}

			if (like_unlike == -1) {
				$("#unlike_" + comment_id).css("display", "none");
				$("#like_" + comment_id).show();
			}

		},
		error: function (data) {
			alert("error : " + JSON.stringify(data));
		}
	});
}