

function login() {

    $("#log_in").submit(function (event) {
        event.preventDefault();
        $('#loader').show();
        var form = $(this);
        console.log(form.attr("id"));

        $.ajax({
            url: form.attr("action"),
            type: 'post',
            dataType: 'json',
            data: form.serialize(),
            success: function (response) {
                console.log(response);
                console.log("successentry");
                if (response.success) {
                    $('#loader').hide();
                    console.log("success");
                    $("#user_id").val(response.user_id);
                    $("#login-form").hide();
                    $("#otp-check-form").show();
                } else {
                    $('#loader').hide();
                    console.log(response.error);
                    const idArray = ["mail_id", "password"];
                    const errorArray = ["mail_id_error", "password_error"];

                    errorDisplay(errorArray, idArray, response.error);

                }
            },
            error: function (response) {
                console.log(response);
            }

        });

    })
}


// sign up

function signup() {
    console.log("hello");
    $("#signup").submit(function (event) {
        event.preventDefault();
        $('#loader').show();
        console.log("entry");
        var form = $(this);
        console.log(form.attr("id"));
        console.log(form.serialize());
        $.ajax({
            url: form.attr("action"),
            type: 'post',
            dataType: 'json',
            data: form.serialize(),
            success: function (response) {
                console.log(response);
                if (response.success) {
                    console.log("successentry");

                    $('#loader').hide();
                    window.location.href = response.url;
                } else {
                    $('#loader').hide();
                    console.log(response.error);
                    const idArray = ["first_name", "last_name", "mail_id", "password", "confirm_password"];
                    const errorArray = ["first_name_error", "last_name_error", "mail_id_error", "password_error", "confirm_password_error"];

                    errorDisplay(errorArray, idArray, response.error);

                }
            },
            error: function (response) {
                console.log(response);
            }

        });

    })
}

function otpCheck(form) {

    //removeError()
    $('#loader').show();
    console.log("entry");
    $.ajax({
        url: form.attr("action"),
        type: 'post',
        dataType: 'json',
        data: form.serialize(),
        success: function (response) {
            console.log(response);
            console.log("successentry");
            if (response.success) {
                $('#loader').hide();
                console.log("success");

                window.location.href = response.url;
            } else {
                $('#loader').hide();

                $("#otp_error").text(response.msg);

            }
        },
        error: function (response) {
            console.log(response);
        }

    });
}
function forgetPassword(form) {
    removeError()
    $('#loader').show();
    $("#alert-msg").hide();
    console.log("entry");
    console.log(form.attr("action"));
    $.ajax({
        url: form.attr("action"),
        type: 'post',
        dataType: 'json',
        data: form.serialize(),
        success: function (response) {
            console.log(response);
            console.log("successentry");
            if (response.success) {
                $('#loader').hide();
                console.log("success");
                $("#alert-msg").text(response.msg);
                $("#alert-msg").show();
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            } else {
                $('#loader').hide();
                console.log(response.error);
                const idArray = ["fp_mail_id"];
                const errorArray = ["fp_mail_id_error"];

                errorDisplay(errorArray, idArray, response.error);

            }
        },
        error: function (response) {
            console.log(response);
        }

    });

}

function removeError() {
    var errorElements = document.getElementsByClassName("error");
    for (let j = 0; j < errorElements.length; j++) {
        errorElements[j].style.display = "none";
    }
}
function errorDisplay(errorArray, idArray, messageArray) {
    for (let i = 0; i < idArray.length; i++) {
        // console.log(idArray[i]);
        var element = document.getElementById(errorArray[i])
        //console.log(element,"element");
        if (element) {
            if (idArray[i] in messageArray) {
                //       console.log(errorArray[i]);
                element.style.display = "block";
                element.innerText = messageArray[idArray[i]];
            } else {
                element.style.display = "none";
            }
        }
    }
}

function orderUpdate(form) {
    console.log("submit2");
    $('#loader').show();
    console.log("entry");
    console.log(form.attr("id"));
    console.log(form.serialize());
    $.ajax({
        url: form.attr("action"),
        type: 'post',
        dataType: 'json',
        data: form.serialize(),
        success: function (response) {
            console.log(response);
            $('#loader').hide();

            if (response.success) {
                console.log("successentry");
                var linkId = document.getElementById("redirect");
                console.log(linkId);
                linkId.setAttribute("href", response.url);

                var formId = form.attr("id")
                var inputElement = document.querySelector('#' + formId + ' input[name="isEdit"]');
                console.log(inputElement);
                if (inputElement) {
                    $("#notification").text("Updated the order successfully!");
                }
                else $("#notification").text("Created the order successfully!");
                $("#AlertModal").modal('show');
            } else {
                console.log(response.error);
                console.log("failure");
                const idArray = ['customer_id', 'order_date', 'type', 'colour', 'length', 'texture', 'ext_size', 'quantity', 'due_date'];
                const errorArray = ["customer_id_error", "order_date_error", "type_error", "colour_error", "length_error", "texture_error", "ext_size_error", "quantity_error", "due_date_error"];

                errorDisplay(errorArray, idArray, response.error);

            }
        },
        error: function (response) {
            console.log(response);
        }

    });

}

function orderDelete(url, orderListId) {
    console.log("submit2");
    $('#loader').show();
    console.log("entry");
    //var form = $(this);

    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: { orderListId: orderListId },
        success: function (response) {
            console.log(response);
            $('#loader').hide();

            if (response.success) {
                console.log("successentry");


                window.location.href = response.url;
            } else {
                console.log(response.error);
                console.log("failure");

            }
        },
        error: function (response) {
            console.log(response);
        }

    });

}
function mapEditOrderData(order, url) {

    console.log("map")
    var editOrderData = order;
    console.log(typeof (editOrderData))
    if (editOrderData && Object.keys(editOrderData).length > 0) {
        $("#Action-type").text("Edit Order");
        console.log("editOrderData", editOrderData);
        var form = document.getElementById("orderForm");

        form.action = url + editOrderData['order_list_id'];
        var inputs = form.querySelectorAll("input");
        console.log(inputs)
        console.log("inputs", inputs);
        inputs.forEach(input => {
            console.log("input", input);
            input.value = editOrderData[input.id];
        })
        console.log(inputs)
        var drpdwns = form.querySelectorAll("select");
        console.log("drpdwns", drpdwns);
        drpdwns.forEach(drpdwn => {
            console.log("drpdwn", drpdwn);
            console.log("drpdwnoption", drpdwn.options);
            var options = drpdwn.options;

            for (let index = 0; index < options.length; index++) {
                const option = options[index];
                if (option.value == editOrderData[drpdwn.id]) {
                    option.selected = true;
                };

            }

        })
        var flag = document.createElement("input");
        flag.setAttribute("type", "hidden");
        flag.setAttribute("value", "true");
        flag.setAttribute("name", "isEdit");
        flag.setAttribute("id", "isEdit");
        form.insertBefore(flag, form.firstChild);
        $("#ord-item-button").hide();
        //  $("#item-button").hide();
        $("#item-form").show();
    }
}

function generateId(url) {

    $.ajax({
        url: url,
        type: 'get',
        dataType: 'json',
        success: function (response) {
            console.log(response);
            if (response.success) {
                console.log("successentry");

                console.log("response.output", response.output);
                // var inputs = form.querySelectorAll("input");
                //window.location.href = response.url;
                $("#order_id").val(response.output[0]);
                $("#item_id").val(response.output[1]);
                $("#item-form").show();
                $("#ord-item-button").hide();
                //  $("#item-button").hide();
            } else {
                // $('#loader').hide();
                console.log(response.error);
                console.log("failure");

            }
        },
        error: function (response) {
            console.log(response);
        }

    });
}

function generateItemId(url, orderId) {

    $.ajax({
        url: url,
        type: 'get',
        dataType: 'json',
        success: function (response) {
            console.log(response);
            if (response.success) {
                console.log("successentry");

                console.log("response.output", response.output);
                // var inputs = form.querySelectorAll("input");
                //window.location.href = response.url;
                $("#order_id").val(orderId);
                $("#item_id").val(response.output);
                $("#item-form").show();
                $("#ord-item-button").hide();
            } else {
                // $('#loader').hide();
                console.log(response.error);
                console.log("failure");

            }
        },
        error: function (response) {
            console.log(response);
        }

    });
}

function mapItemId(item_ord_Id) {
    console.log("entry");
    if (item_ord_Id && Object.keys(item_ord_Id).length > 0) {
        console.log("map");
        $("#order_id").val(item_ord_Id['order_id']);
        $("#item_id").val(item_ord_Id['item_id']);
        $("#ord-item-button").hide();
        $("#item-form").show();
    }
}

function InsertTaskDetail(form) {

    $('#loader').show();
    // var form = $(this);
    console.log(form.attr("id"));

    $.ajax({
        url: form.attr("action"),
        type: 'post',
        dataType: 'json',
        data: form.serialize(),
        success: function (response) {
            console.log(response);
            console.log("successentry");
            $('#loader').hide();

            if (response.success) {
                console.log("success");
                window.location.href = response.url;

            } else {
                console.log(response.error);
                const idArray = ["task_name", "hours_taken", "supervisor", "is_qa", "quality_analyst"];
                const errorArray = ["task_name_error", "hours_taken_error", "supervisor_error", "is_qa_error", "quality_analyst_error",];

                errorDisplay(errorArray, idArray, response.error);

            }
        },
        error: function (response) {
            console.log(response);
        }

    });
}

function viewTaskDetail(url, taskDetId) {

    $('#loader').show();

    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: { task_detail_id: taskDetId },
        success: function (response) {
            console.log(response);
            console.log("successentry");

            $('#loader').hide();
            console.log("success");
            console.log("response", response.output)

            var taskDetContainer = document.getElementById('view-task-detail-modal');

            $.each(response.output, function (index, value) {
                console.log(typeof (index))
                console.log(typeof (value))
                if (typeof (value) == "object") {
                    var container = document.getElementById("qc");
                    console.log("here", response.output.qc);
                    response.output.qc.forEach(element => {
                        $.each(element, function (index1, value1) {
                            console.log("1", value1);
                            var data = document.createElement("p")
                            data.innerText = value1;
                            container.append(data);
                        })

                    })

                }
                else {

                    var element = document.getElementById(index);
                    element.innerText = value;
                }



            });


            $("#view-task-detail-modal").modal("show");


        },
        error: function (response) {
            console.log(response);
        }

    });


}
function taskDetailDelete(url, taskDetailId) {
    console.log("submit2");
    $('#loader').show();
    console.log("entry");

    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: { task_detail_id: taskDetailId },
        success: function (response) {
            console.log(response);
            $('#loader').hide();

            if (response.success) {
                console.log("successentry");


                window.location.href = response.url;
            } else {
                console.log(response.error);
                console.log("failure");

            }
        },
        error: function (response) {
            console.log(response);
        }

    });

}
function parentTaskUpd(url, parent_task_id, task_detail_id) {
    $('#loader').show();
    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: { task_detail_id: task_detail_id, parent_task_id: parent_task_id },
        success: function (response) {
            console.log(response);
            $('#loader').hide();

            if (response.success) {
                console.log("successentry");


                window.location.href = response.url;
            } else {
                console.log(response.error);
                console.log("failure");

            }
        },
        error: function (response) {
            console.log(response);
        }
    })
}
function searchStocks(form) {
    console.log(form.attr("id"));
    $.ajax({
        url: form.attr("action"),
        method: 'post',
        dataType: 'json',
        data: form.serialize(),
        success: function (response) {
            if (response.success) {
                let stocks = response.output;
                //console.log(stocks);
                $('#dropdown-stock').html('');
                var selectedList = GetSelectedList();

                $.each(stocks, function (index, value) {
                    //console.log(value);
                    var stock = value.colour + " - " + value.length + " - " + value.texture + " - " + value.quantity;
                    // console.log(value.name);
                    // //$("#emailResults").append('<option value="' + value.email_id + '">' + value.email_id + '</option>');
                    // innerText = value.count ? value.name + ' - ' + value.count + ' customer(s)' : value.name;

                    // var className = "";
                    disabled = "";

                    var flag = selectedList.includes(value.stock_list_id)
                    if (flag) {
                        disabled = "disabled";
                    }
                    $("#dropdown-stock").append("<option value='" + value.stock_list_id + "' " + disabled + " >" + stock + "</option>");
                    //$("#dropdown-stock").append("<option class='" + className + "' onclick='AddEmails(" + JSON.stringify(value) + ")'>" + innerText + "</li>");


                });

            } else {
                $('#emailResults').html('');
            }
        }
    });

    //  });
}

function searchOrder(url, query) {
    console.log(query)
    var ul = document.getElementById("autocompleteList");
    if (query != '') {
        $.ajax({
            url: url,
            method: 'post',
            dataType: 'json',
            data: {
                like: query
            },
            success: function (response) {
                if (response.success) {
                    let orders = response.output;
                    console.log(orders);
                    $('#autocompleteList').html('');
                    var input = document.getElementById("orderidsearch");

                    ul.classList.remove("d-none");
                    console.log(ul);
                    var clear = document.getElementById("clear");
                    $.each(orders, function (index, value) {
                        //var name = value.name;
                        console.log(value);
                        //$("#emailResults").append('<option value="' + value.email_id + '">' + value.email_id + '</option>');
                        //innerText = value.count ? value.name + ' - ' + value.count + ' customer(s)' : value.name;
                        var li = document.createElement("li");
                        var ord_item_id = value.order_id + " - " + value.item_id;
                        li.textContent = ord_item_id
                        li.addEventListener("click", function () {
                            $("#orderListId").val(value.order_list_id);
                            input.value = ord_item_id;
                            input.readOnly = true; // Set input field to read-only
                            ul.classList.add("d-none");
                            clear.classList.remove("d-none");
                            var outputDiv = document.getElementById("output-data");

                            var inputs = outputDiv.querySelectorAll("input");
                            console.log("inputs", inputs);
                            inputs.forEach(input => {
                                console.log("input", input);
                                var fieldName = input.id;
                                input.value = value[fieldName];
                            })
                        });
                        ul.appendChild(li);

                    });

                } else {
                    $('#autocompleteList').html('');
                }
            }
        });
    } else {
        ul.classList.add("d-none");
    }
    //  });
}

function clearInput() {
    var input = document.getElementById("orderidsearch");
    var ul = document.getElementById("autocompleteList");
    var clear = document.getElementById("clear");
    ul.innerHTML = "";
    if (input.value.length > 0) {
        input.value = "";
        if (input.value == "") {
            clear.classList.add("d-none");
            input.readOnly = false;
        }
    }
    var outputDiv = document.getElementById("output-data");

    var inputs = outputDiv.querySelectorAll("input");
    console.log(inputs)
    console.log("inputs", inputs);
    inputs.forEach(input => {
        var fieldName = input.id;
        input.value = "";
    })
}

//shows preview of the selected stock
const inputArr = [];
function saveStockInput(form) {
    //if (inputArr) {
    var qty = form.find('input[name="quantity"]').val();
    var stockId = form.find('select[name="stock_id"]').val();
    //console.log(qty);
    //console.log(stockId);
    var qtyElement = document.getElementById("quantity");
    var selectElement = document.getElementById("dropdown-stock");
    var selectedOption = selectElement.options[selectElement.selectedIndex];
    console.log("selectedOption", selectedOption);
    const input = { stock_id: selectedOption.value, quantity: qty };
    console.log(input);
    //inputArr.push(input);
    console.log(inputArr)

    var selectedOptionText = selectedOption.innerText;
    var stockArr = selectedOptionText.split(" - ");
    console.log("qty", stockArr[3]);
    console.log(selectedOptionText);
    //     var selectedList = GetSelectedList();
    // console.log("a",selectedList)


    //Adding the preview of a selected stock if condition satisfies.
    if (parseFloat(qty) <= parseFloat(stockArr[3])) {
        // var flag = selectedList.includes(stockId)
        // console.log("flag",flag);
        if (stockId) {
            document.querySelectorAll("#dropdown-stock option").forEach(opt => {
                //console.log(opt)
                if (opt.value == stockId) {
                    opt.disabled = true;
                }
            });
            var previewContainer = document.getElementById('preview');
            var stockInput = document.createElement('div');

            stockInput.className = 'stockInput';
            stockInput.innerText = selectedOptionText;



            stockInput.id = selectedOption.value;
            var removeButton = document.createElement('button');
            removeButton.innerText = 'X';
            removeButton.onclick = function () {
                document.querySelectorAll("#dropdown-stock option").forEach(opt => {
                    //console.log(opt)
                    if (opt.value == stockId) {
                        opt.disabled = false;
                    }
                });
                previewContainer.removeChild(stockInput);
            }
            stockInput.appendChild(removeButton);
            previewContainer.appendChild(stockInput);
            inputArr.push(input);
        }
        else {

            $("#stock_id_error").text("This stock is alreay selected.")
        }
    }
    else {
        $("#quantity_error").text("Please enter valid quantity.")
    }
}

function GetSelectedList() {
    var elements = document.getElementsByClassName('stockInput');
    var stockInputArray = [];
    console.log("elements", elements);
    for (var i = 0; i < elements.length; i++) {
        console.log("here", elements[i]);
        var id = elements[i].id;
        stockInputArray.push(id);
    }
    console.log("here", stockInputArray);

    return stockInputArray;
}
//append the selected stock into the form.
function createTask(url) {
    
    var orderId = $("#orderListId").val();
    var taskId = $("#dropdown-task").val();
    console.log(inputArr, orderId, taskId);
    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: { order_list_id: orderId, task_detail_id:taskId, stock:inputArr},
        success: function (response) {
            console.log("success", response);
            console.log(response);
            if (response.success) {
                console.log("successentry");
                // var inputs = form.querySelectorAll("input");
                //window.location.href = response.url;
            } else {
                // $('#loader').hide();
                console.log(response.error);l
                console.log("failure");
            }

        },
        error: function (xhr, status, error, response) {
            console.log("error", response);
            // console.log("error", response.data.id); // Access data-id value
            console.log("error", xhr.responseText);
        }

    });
   // console.log($('#create-task-form').serializeArray());
}
function employeeDetailDelete(url, employeeDetailId) {
    console.log("submit2");
    // $('#loader').show();
    console.log("entry", employeeDetailId);
    //var form = $(this);

    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: { id: employeeDetailId },
        success: function (response) {
            console.log("success", response);
            console.log(response);
            if (response.success) {
                console.log("successentry");
                // var inputs = form.querySelectorAll("input");
                window.location.href = response.url;
            } else {
                // $('#loader').hide();
                console.log(response.error);
                console.log("failure");
            }

        },
        error: function (xhr, status, error, response) {
            console.log("error", response);
            // console.log("error", response.data.id); // Access data-id value
            console.log("error", xhr.responseText);
        }

    });
}
function stockDetailDelete(url, stockDetailId) {
    console.log("submit2");
    // $('#loader').show();
    console.log("entry", stockDetailId);
    //var form = $(this);

    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        data: { id: stockDetailId },
        success: function (response) {
            console.log("success", response);
            if (response.success) {
                console.log("successentry");
                // var inputs = form.querySelectorAll("input");
                window.location.href = response.url;
            } else {
                // $('#loader').hide();
                console.log(response.error);
                console.log("failure");
            }
        },
        error: function (xhr, status, error, response) {
            console.log("error", response);
            // console.log("error", response.data.id); // Access data-id value
            console.log("error", xhr.responseText);
        }

    });
}

