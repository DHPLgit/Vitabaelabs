

 // Function to add active class to the navbar menu item
 function setActiveMenuItem() {
    // Get the current URL
    var currentUrl = window.location.href;
    
    // Select the navbar menu items
    var menuItems = document.querySelectorAll('.navbar-nav .nav-item');

    // Loop through each menu item
    menuItems.forEach(function(menuItem) {
        // Get the menu item's link
        var menuItemLink = menuItem.querySelector('.nav-link').getAttribute('href');
        
        // Check if the current URL contains the menu item's link
        if (currentUrl.includes(menuItemLink)) {
            // Add the active class to the menu item
            menuItem.classList.add('active');
        }
    });
}

// Call the setActiveMenuItem function when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setActiveMenuItem();
});